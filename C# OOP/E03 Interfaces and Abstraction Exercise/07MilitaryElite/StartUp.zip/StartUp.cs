﻿using _07MilitaryElite.Run;


IEngine engine = new Engine();
engine.Run();

