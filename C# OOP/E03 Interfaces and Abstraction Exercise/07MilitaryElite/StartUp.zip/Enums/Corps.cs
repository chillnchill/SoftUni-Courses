﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces = 0,
        Marines = 1
    }
}
