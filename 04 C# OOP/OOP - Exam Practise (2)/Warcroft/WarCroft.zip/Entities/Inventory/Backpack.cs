﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarCroft.Entities.Inventory
{
    //this doesn't need its own constructor because the parent class has one with a default value (100)
    public class Backpack : Bag
    {
    }
}
